function my$(id){
    return document.getElementById(id);
}