//根据id获取元素
function my$(id){
    return document.getElementById(id);
}